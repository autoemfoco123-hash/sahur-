#!/bin/sh
# sahur launcher (godot 3.6 · opengl 2.1)
#   ./sahur.sh             automatic (picks graphics on first launch)
#   ./sahur.sh potato      lightest
#   ./sahur.sh software    no working gpu driver: renders on the cpu
cd "$(dirname "$0")" || exit 1
BIN=./Sahur.x86_64
chmod +x "$BIN" 2>/dev/null
case "$1" in
	potato|low|high) exec "$BIN" "--$1" ;;
	software) LIBGL_ALWAYS_SOFTWARE=1 GALLIUM_DRIVER=llvmpipe exec "$BIN" --potato ;;
esac
exec "$BIN" "$@"
