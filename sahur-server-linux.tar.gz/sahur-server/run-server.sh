#!/bin/sh
# sahur dedicated server (headless, no gpu needed). udp 7777 (game) + udp 7778 (lan discovery).
#   ./run-server.sh                 server named "sahur server"
#   ./run-server.sh "my server"     custom name
cd "$(dirname "$0")" || exit 1
chmod +x ./sahur-server.x86_64 2>/dev/null
exec ./sahur-server.x86_64 --main-pack Sahur.pck --server "--name=${1:-sahur server}"
